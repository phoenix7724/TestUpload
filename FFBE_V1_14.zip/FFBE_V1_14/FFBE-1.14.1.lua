--===========  setting  ============
Settings:setCompareDimension(true, 720)--執行圖形比對時螢度的解析度。根據compareByWidth的值的值設定成寬度或高度
Settings:setScriptDimension(true, 1440)--用於參考App解析度腳本內座標位置
Settings:set("MinSimilarity", 0.8)
setContinueClickTiming( 10, 100) 	-- int downMs: 按下幾毫秒	--int intervalMs: 相鄰的click 間隔幾毫秒
setDragDropTiming(100, 100)			--downMs: 開始移動前壓不住不動幾毫秒	upMs: 最後放開前停住幾毫秒
setDragDropStepCount(5)				--stepCount: 從啟始點到目的地分幾步移動完
setDragDropStepInterval(50)	--intervalMs: 每次移動間停留幾毫秒
screen = getAppUsableScreenSize()
screenX = screen:getX()
screenY = screen:getY()

dialogInit()	-- New dialog
--addCheckBox("DEBUG", "Debug mode", false)
DEBUG = false
addTextView("  ◆   執行次數：") addEditNumber("CLEAR_LIMIT", 999)	newRow()
addTextView("  ◆   體力不足時等待 ( 分 )：") addEditNumber("WAIT_TIME", 3)	newRow()
--addCheckBox("ITEM_MAKE", "檢查道具製作，頻率：每", false)		addEditNumber("MAKE_ROUND", 2)	addTextView("回")	newRow()
--addCheckBox("WEAPON_ON", "鍛造", false)	--addEditNumber("WEAPON_POS", 1)
--addCheckBox("ABILITY_ON", "技能", false)	--addEditNumber("ABILITY_POS", 1)
--addCheckBox("ITEM_ON", "調合", false)		--addEditNumber("ITEM_POS", 1)	newRow()
ITEM_MAKE = false		MAKE_ROUND = 0	WEAPON_ON = false		ABILITY_ON = false	ITEM_ON = false
addCheckBox("FAST_MODE", "快速模式", true)  addTextView("   選擇關卡：") addEditNumber("QUEST", 1)		newRow()
addCheckBox("CONTINUE_CLICK", "結束時使用 Continue Click", true)		newRow()
addTextView("          or Click 幾次：") addEditNumber("CLICK_TIMES", 9)	newRow()
addCheckBox("AUTO_BATTLE", "自動戰鬥", true) addTextView("  or 行動成員 ( 1~6 ) ") addEditNumber("ATTACKER", 6)	newRow()
--addTextView("戰鬥中使用：")
--addCheckBox("USE_SUMMON", "召喚獸", false)
--addCheckBox("USE_ITEM", "道具", false)
-- addCheckBox("USE_ABILITY", "技能", false) newRow()
addCheckBox("USE_ABILITY_LB", "極限技能", false) newRow()
USE_SUMMON = false	USE_ITEM = false		USE_ABILITY = false
addCheckBox("FRIEND", "新朋友申請", false) addEditNumber("FRIEND_LOOP", 9) addTextView(" 回")		newRow()
addCheckBox("BUY", "使用寶石回復體力 ", false) addEditNumber("BUY_LOOP", 2) addTextView(" 回")	newRow()
dialogShow("Trust Master Maker".." - "..screenX.." × "..screenY)
--=========== Region set ==============
-- 1080 x 1920 ( x, y, w, h )
X = 1440	--	1080 / 540 / 270 / 135
Y = 2560	--	1920 / 960 / 480 / 240
-- 1/2
upper = Region(	0,   	0,   	X,	  	Y/2 	)
center= Region( 0,		Y/4,   	X,		3*Y/4	)
lower = Region( 0,		Y/2,   	X,		Y 		)
left  = Region( 0,		0,		X/2,	Y 		)
right = Region( X/2,	0,  	X,		Y 		)
-- 1/4
upperLeft  = Region(	0,		0,  	X/2,	Y/2 )
upperRight = Region(	X/2,	0,  	X,  	Y/2 )
lowerLeft  = Region(	0,   	Y/2,  	X/2,  	Y 	)
lowerRight = Region(	X/2,   	Y/2,  	X,		Y	)
upperUpper = Region(	0,     	0,  	X,  	Y/4 )
upperLower = Region(	0,   	Y/4, 	X,  	Y/2 )
lowerUpper = Region(	0,   	Y/2,  	X,  	3*Y/4 )
lowerLower = Region(	0, 		3*Y/4,	X,		Y 	)
leftLeft   = Region(	0,		0,  	X/4,    Y 	)
leftRight  = Region(	X/4,    0,  	X/2,    Y 	)
rightLeft  = Region(	X/2,    0,  	3*X/4,	Y 	)
rightRight = Region(	3*X/4,	0,  	X,		Y 	)
-- 1/8
upperUpperLeft  = Region(	0,		0, 		X/2, 	Y/4 	)
upperUpperRight = Region(	X/2,	0, 		X, 		Y/4 	)
upperLowerLeft  = Region(   0,   	Y/4, 	X/2, 	Y/2 	)
upperLowerRight = Region(	X/2,   	Y/4, 	X, 		Y/2 	)
lowerUpperLeft  = Region(   0,   	Y/2, 	X/2,	3*Y/4 	)
lowerUpperRight = Region(	X/2,   	Y/2, 	X, 		3*Y/4 	)
lowerLowerLeft  = Region(   0, 		3*Y/4,	X/2, 	Y 	)
lowerLowerRight = Region( 	X/2, 	3*Y/4,	X, 		Y 	)
--
--	LIMIT	420		950
--	1250	 1		 2
--	1450	 3		 4
--	1650	 5		 6
--
-- ==========  main var ===========
CLEAR = 0				-- Stage clear times
STEP = 1				-- Step now
STEP_TEMP = STEP
STEP_REPEAT = 0			-- Loop times
RECHECK = 4				-- Loop times to recheck step
FindPicNumber = 0   	-- Count Quests
TIMER = Timer()			-- Timer of loop
TIMER2 = Timer()		-- Timer of step
TIMER_ITEM = Timer() 	-- Time to make ITEMs
WEAPON_PIC = Pattern("Weapon_Skin_Shell.png")	-- 要鍛冶的道具圖片名稱
ABILITY_PIC = Pattern("Ability_Detecte.png")	-- 要製作的能力圖片名稱
ITEM_PIC = Pattern("ITEM_Potion.png")			-- 要調合的道具圖片名稱
MAKE_STEP = 20
nextLocation     = Location( 0.45*screenX, 0.845*screenY)		--	Use middle position between 1 and 2
--nextLocation1     = Location( 0.5*screenX, 0.83*screenY)
--nextLocation2    = Location( 0.416*screenX, 0.854*screenY)
noFriendLocation = Location( screenX-10, screenY-20)
friendLocation   = Location( 0.98*screenX, 0.91*screenY)
abilityLocation  = Location( screenX, 0.90*screenY)
Location_1 = Location( 0.39*screenX, 0.65*screenY )		Location_2 = Location( 0.88*screenX, 0.65*screenY )
Location_3 = Location( 0.39*screenX, 0.755*screenY )	Location_4 = Location( 0.88*screenX, 0.755*screenY )
Location_5 = Location( 0.39*screenX, 0.86*screenY )		Location_6 = Location( 0.88*screenX, 0.86*screenY )
-- User Input Error Check ( > 1 )
if( QUEST < 1) 							then QUEST = 1 		end
if( ATTACKER < 1 or ATTACKER > 6 ) 		then ATTACKER = 6 	end
if( CLEAR_LIMIT < 1 ) 					then CLEAR_LIMIT = 1 end
if( MAKE_ROUND < 1 )						then MAKE_ROUND = 1  end
WAIT_TIME = WAIT_TIME * 60

setBrightness(0)

--=========== Main function set ============
function stepCheck()
	if(rightRight:exists("BattleStage.png", 0)) then				if( DEBUG == true) then print("Pic 01") end return 1
	elseif(lowerUpperLeft:exists("No_Buy.png", 0)) then			if( DEBUG == true) then print("Pic 02") end return 1
	elseif(upperUpper:exists("Mission_Clear.png", 0)) then		if( DEBUG == true) then print("Pic 13") end return 7	--	2016/04/25 New
	elseif(upper:exists("Mission_Check.png", 0))	then				if( DEBUG == true) then print("Pic 03") end return 10	--	2016/04/25 New
	elseif(upperLowerRight:exists("Select_Friend.png", 0)) then	if( DEBUG == true) then print("Pic 04") end return 2
	elseif(lowerLower:exists("GO.png", 0)) then					if( DEBUG == true) then print("Pic 05") end return 3
	elseif(lowerLowerLeft:exists("AUTO.png", 0)) then				if( DEBUG == true) then print("Pic 06") end return 4
	elseif(center:exists("OK2-status.png", 0)) then				if( DEBUG == true) then print("Pic 07") end return 5	--	Get Exp Check OK
	elseif(center:exists("Friend_OK.png", 0)) then				if( DEBUG == true) then print("Pic 08") end return 9	--	Make Friend Check OK
	elseif(upperUpper:exists("NEXT2-status.png", 0)) then			if( DEBUG == true) then print("Pic 09") end return 8	--	Get Item Check OK
	elseif(lowerUpper:exists("OK1.png", 0)) then					if( DEBUG == true) then print("Pic 10") end return 4
	elseif(lowerLower:exists("NEXT1.png", 0)) then				if( DEBUG == true) then print("Pic 11") end return 5
	elseif(upperUpper:exists("Unit_EXP.png", 0)) then				if( DEBUG == true) then print("Pic 12") end return 6
	elseif(lowerUpperLeft:exists("Not_Make_Friend.png", 0)) then	if( DEBUG == true) then print("Pic 14") end return 9
	else 						if( DEBUG == true) then 	print("Pic 00") print("Connecting Error …")  end return 1	--	Unknow ( Network Error )
	end

end
switch = {
	[  1 ] = function()
			-- User Input > Quests，Quest = MAX of Quests
			FindPicNumber = table.getn(regionFindAllNoFindException(rightRight, "BattleStage.png"))
			if( FindPicNumber > 0 and FindPicNumber < QUEST ) then
				QUEST = FindPicNumber
				--toast("Reset Quest : "..QUEST)
			end
			for i, m in ipairs(listToTable(rightRight:findAllNoFindException("BattleStage.png"))) do
				if( i < QUEST ) then
					--toast("Skip Stage："..i)
				elseif( i == QUEST ) then
					toast("Select Stage："..i)
					click(m)
					if( BUY == true and BUY_LOOP > 0 ) then
						STEP = 10
						if(lowerUpperRight:exists("BUY.png",1)) then
							lowerUpperRight:click("BUY.png")
							BUY_LOOP = BUY_LOOP - 1
						end
						break
					elseif(exists("No_Buy.png", 0)) then
						click("No_Buy.png")
						print("wait "..WAIT_TIME.." sec ....")
						wait(WAIT_TIME)
					else
						STEP = 10
						break
					end
				else
					STEP = stepCheck()
					print("Step Check 1 : "..STEP)
					toast("Step Check 1 : "..STEP)
					break
				end
			end
		end,		-- Choose Quest
	[ 10 ] = function()
		--if (lowerLower:exists("NEXT3.png",0)) then
		--	lowerLower:click("NEXT3.png")
			STEP = 2
		-- end
	end,		-- Mission Check ( 2016/04/25 New )
	[  2 ] = function()
			if(upperLowerRight:exists("Select_Friend.png", 0)) then -- First
				upperLowerRight:click("Select_Friend.png")
				STEP = 3
			elseif( FRIEND == true and FRIEND_LOOP > 0 ) then   -- Last
				--continueClick(friendLocation,3)
				click(friendLocation)
				STEP = 3
				if( DEBUG == true ) then
					print("friendLocation "..FRIEND_LOOP.."："..friendLocation:getX().."×"..friendLocation:getY())
				end
			end
		end,		-- Choose Friend
	[  3 ] = function()
			if(lowerLower:exists("GO.png", 5)) then
				lowerLower:click("GO.png")
				STEP = 4
			end
		end,		-- Team Check
	[  4 ] = function()
			if(lowerLowerLeft:exists("AUTO.png", 10)) then
				local AUTO_BUTTON = find("AUTO.png")
				local AUTO_POS = Location(AUTO_BUTTON:getX(), AUTO_BUTTON:getY())
				if(AUTO_BATTLE == true) then
					lowerLowerLeft:click(AUTO_POS)
					while( true ) do
						if not (lowerLowerLeft:exists("AUTO.png", 0)) then
							if(lowerUpper:exists("OK1.png",0)) then	-- Network Connecting Error
								lowerUpper:click("OK1.png")
							else
								STEP = 5
								break
							end
						end
					end
				else
					local LIMIT = listToTable(lower:findAllNoFindException("Limit.png"))
					local OFFSET = 500
					local ITEM_COUNT = 10
					local FIGHT_COUNT = 0
					local BREAK_CHECK = 0

					while (true) do
						if (FIGHT_COUNT >= 2) then
							for i, m in ipairs(LIMIT) do

								if not (lowerLowerLeft:exists("AUTO.png", 0)) then
									BREAK_CHECK = 1
									break
								end

								--print(LIMIT[i])	-- Get Position
								if( USE_SUMMON == true and i == 1 ) then
									dropToS = Location(m:getX()+OFFSET,m:getY())		-- 向右滑
									dragDrop(m, dropToS)	-- Use Summon ( → )
									-- ★ 要加一行判斷是否可使用召喚獸
									click(Location_2)		-- Select Summon
								elseif( USE_ITEM == true and ITEM_COUNT >= 1 ) then
									dropToI = Location(m:getX()-OFFSET,m:getY())		-- 向左滑
									dragDrop(m, dropToI)	-- Use Item ( ← )
									click(Location_2)		-- Item Select
									click(m)				-- Target Select
									ITEM_COUNT = ITEM_COUNT -1
									toast("ITEM Count="..ITEM_COUNT)
								elseif( USE_ABILITY == true ) then
									dropToA = Location(m:getX()+OFFSET,m:getY())		-- 向右滑
									dragDrop(m, dropToA)	-- Use Ability ( → )
									wait(1)
									-- dragDrop(Location_6, Location_2)
									--click(abilityLocation)
									click(Location_1)


									-- ★ 能力位置難以定位 -__-
								elseif( USE_ABILITY_LB == true ) then
									dropToLB = Location(m:getX()-OFFSET,m:getY())		-- 向右滑
									dragDrop(dropToLB, m)	-- Use Ability ( → )

									-- dragDrop(Location_6, Location_2)
									--click(abilityLocation)
									--click(Location_1)
									if(lowerUpperLeft:exists("Limit_LB.png", 1)) then
										lowerUpperLeft:click("Limit_LB.png")
										--wait(1)
										if(lowerLowerRight:exists("Limit_Back.png", 1)) then
											click(m)
										end
									--elseif (lowerLowerRight:exists("Limit_Back.png", 0)) then
									--	lowerLowerRight:click("Limit_Back.png")
									else
										dragDrop(m, dropToLB)	-- 向左滑
										--wait(1)
									end
								else
								end
								--click(m)
								if( i >= ATTACKER) then
									click(AUTO_POS)
									click(AUTO_POS)
									wait(3)
									break
								end
							end

							if (BREAK_CHECK == 1) then
								STEP = 5
								break
							end

							while (true) do
								if(lowerLowerLeft:exists("Fight_Now.png", 0)) then
									wait(1)
								elseif (lowerLowerLeft:exists("Fight_Finish.png", 0)) then
									break
								end
							end

						else
							click(AUTO_POS)
							click(AUTO_POS)
							wait(3)

							while (true) do
								if(lowerLowerLeft:exists("Fight_Now.png", 0)) then
									wait(1)
								else
									break
								end
							end

						end

						FIGHT_COUNT = FIGHT_COUNT + 1
					end
				end
			else
				lowerUpper:existsClick("OK1.png",0)	-- Network Connecting Error
			end
		end,		-- ( Network Connecting )	Battles
	[  5 ] = function()
            if( FAST_MODE == true ) then
				if( upperLower:exists("Result.png", 12 )) then
					--toast("Result 1")
					if ( CONTINUE_CLICK == true ) then
						continueClick(nextLocation,40)	-- ★ Continue Click OFF
					else
						for i=1,CLICK_TIMES  do	click(nextLocation) end
					end
					STEP = 9
					if( upperLower:exists("Result.png", 0 )) then
						if (lowerLower:exists("NEXT1.png",0)) then
							lowerLower:click("NEXT1.png")
							STEP = 6
						end
					end
					if( DEBUG == true ) then
						print("    nextLocation："..nextLocation:getX().."×"..nextLocation:getY())
					end
				elseif(lowerUpper:exists("OK1.png",0)) then	-- Network Connecting Error
					lowerUpper:click("OK1.png")
				end
			elseif(lowerLower:exists("NEXT1.png", 3)) then	-- 待修改
                --local NEXT = find("NEXT1.png")
                --local SKIP = Location(NEXT:getX(), NEXT:getY())
                --if( FindPicNumber < 4 ) then
					--toast("Result 2")
				--	continueClick( SKIP ,20)
				--	STEP = 7
				--else
					--toast("Result 3")
					lowerLower:click( "NEXT1.png" )
					STEP = 6
				--end
			else
				-- Network Connecting Error
				center:existsClick("OK2.png", 0)
			end
		end,		-- ( Network Connecting )	Get Gil & Unit Exp & Rank Exp Check
	[  6 ] = function()
			if(upperUpper:exists("Unit_EXP.png", 0)) then
				upperUpper:click("Unit_EXP.png")
				STEP = 7
			end
		end,		-- Get Unit Exp & Trust Exp & Limit Exp Check
	[  7 ] = function()
			if(lowerLower:exists("NEXT2.png", 0)) then
				local home = find("NEXT2.png")
				if( DEBUG == true ) then
					print("SKIP POS："..home:getX().."✕"..home:getY())
				end
				if( CONTINUE_CLICK == true ) then
					lowerLower:continueClick("NEXT2.png",8)	-- ★ Continue Click OFF
				else
					for i=1,2  do	click(nextLocation) end
				end
				STEP = 8
			end
		end,		-- Clear Mission Check
	[  8 ] = function()
			if(lowerLower:exists("NEXT2.png", 0)) then
				if( CONTINUE_CLICK == true ) then
					lowerLower:continueClick("NEXT2.png",3)	-- ★ Continue Click OFF
				else
					for i=1,1  do	click(nextLocation) end
				end
				STEP = 9
			end
		end,		-- Get Item Check
	[  9 ] = function()
			if( FRIEND == true and FRIEND_LOOP > 0 ) then
				lower:existsClick("Make_Friend.png", 0)
				if( lower:exists("OK1.png", 5 )) then
					lower:click("OK1.png")
					FRIEND_LOOP = FRIEND_LOOP -1
				end
			else
				lower:existsClick("Not_Make_Friend.png", 0)
			end
			STEP = 1
			CLEAR = CLEAR + 1
			STEP_REPEAT = 0
			print("◆ Clear : "..CLEAR.." times ( "..TIMER:check().." )")
			toast("Clear : "..CLEAR.." times ( "..TIMER:check().." )")
			TIMER:set()
		end		-- ( Network Connecting )	Make New Friend Check
}

--=========== Make function set ============
function makeStepCheck()
	if(   upper:exists("Weapon_Main.png", 3)) 	then return 20
	elseif(upper:exists("Ability_Main.png", 0)) 	then return 21
	elseif(upper:exists("ITEM_Main.png", 0)) 		then return 22
	else return 29
	end
end
makeSwitch = {
	[ 20 ] = function()
			if( WEAPON_ON == true ) then	makeRound("Weapon_Main.png", WEAPON_PIC	, "Ability_Small.png")
			else	upper:existsClick("Ability_Small.png",0)
			end
		end,
	[ 21 ] = function()
			if( ABILITY_ON == true ) then	makeRound("Ability_Main.png", ABILITY_PIC , "ITEM_Small.png" )
			else	upper:existsClick("ITEM_Small.png",0)
			end
		end,
	[ 22 ] = function()
			if( ITEM_ON == true ) then		makeRound("ITEM_Main.png", ITEM_PIC	, "Make_Return.png"	)
			else	upper:existsClick("Make_Return.png",0)
			end
		end,
	[ 29 ] = function()
			upper:existsClick("Make_Return.png",0)
		end
}
function makeRound( img_main, target_pos, img_next )
	if( upperUpper:exists(img_main)) then
		-- Get Complete Item
		for i, m in ipairs(listToTable(rightRight:findAllNoFindException("Complete_Big.png"))) do
			click(m)
			lowerUpper:existsClick("Complete_OK.png",3)
			lowerUpper:existsClick("Complete_OK.png",0)	-- 鍊晶輝石
		end
		-- Make New Item
		for i, m in ipairs(listToTable(rightRight:findAllNoFindException("Blank.png"))) do
			click(m)
			if( left:exists(target_pos,3)) then
				click(target_pos)
				if( lower:exists("Make_Check.png",3)) then
					click("Make_Check.png")
					if( lowerUpper:exists("Make_Check_YES.png",3)) then
						click("Make_Check_YES.png")
						wait(2)
					end
				end
			end
		end
		upper:existsClick(img_next,3)
	else
		return
	end
end
function itemMake()
	if( upperLeft:exists("Complete_Small.png", 7) ) then
		click("Complete_Small.png")
	elseif( upperLeft:exists("Blank_Small.png", 3)) then
		click("Blank_Small.png")
	else
		return
	end
	MAKE_STEP = 20
	while( true ) do
		if( DEBUG == true ) then
			print("MAKE_STEP："..MAKE_STEP)
			toast("MAKE_STEP："..MAKE_STEP)
		end
		if( MAKE_STEP == 29 ) then
			break
		else
			if( DEBUG == true ) then
				print("Make step checking ...")
				toast("Make step checking ...")
			end
			MAKE_STEP = makeStepCheck()
			makeSwitch[MAKE_STEP]()
		end
	end
end

-- ==========  main program ===========
repeat
	STEP_TEMP = STEP
	if( DEBUG == true) then	-- Debug Mode Setting
	print("step : "..STEP.." , loop : "..STEP_REPEAT.." , timer : "..TIMER2:check())
	TIMER2:set()
	end

	if( STEP == 1 and ITEM_MAKE == true ) then		-- Make item  check timer > 300 sec
		--if( TIMER_ITEM:check() > 300 ) then
		if( CLEAR % MAKE_ROUND == 0 ) then
			toast( "Item timer："..TIMER_ITEM:check())
			print( "Item timer："..TIMER_ITEM:check())
			if( upperRight:exists("Home_Small.png",8)) then
				click("Home_Small.png")
				itemMake()
				lower:existsClick("World_Big.png",5)
				existsClick("MAP_Earth_Temple.png",5)
			end
			TIMER_ITEM:set()
		end
	end

    switch[STEP]()	-- Next step check

	if(STEP_TEMP == STEP) then	-- Step repeat check
		STEP_REPEAT = STEP_REPEAT + 1
	else
		STEP_REPEAT = 0
	end
	if(STEP_REPEAT > RECHECK) then	-- Recheck Step now
		STEP = stepCheck()
		STEP_REPEAT = 0
		print("Step Check 2 : "..STEP)
		toast("Step Check 2 : "..STEP)
	end


until CLEAR == CLEAR_LIMIT